package diwanCertificatesHelper.util;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.Base64;
import java.net.URLEncoder;
// --- <<IS-END-IMPORTS>> ---

public final class java

{
	// ---( internal utility methods )---

	final static java _instance = new java();

	static java _newInstance() { return new java(); }

	static java _cast(Object o) { return (java)o; }

	// ---( server methods )---




	public static final void decrypt (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(decrypt)>> ---
		// @sigtype java 3.5
		// [i] field:0:required strToDecrypt
		// [i] field:0:required secret
		// [o] field:0:required decryptedValue
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	strToDecrypt = IDataUtil.getString( pipelineCursor, "strToDecrypt" );
			String	secret = IDataUtil.getString( pipelineCursor, "secret" );
		pipelineCursor.destroy();
		String decryptedValue = decrypt(strToDecrypt, secret);
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "decryptedValue", decryptedValue );
		pipelineCursor_1.destroy();
			
		// --- <<IS-END>> ---

                
	}



	public static final void encrypt (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(encrypt)>> ---
		// @sigtype java 3.5
		// [i] field:0:required strToEncrypt
		// [i] field:0:required secret
		// [o] field:0:required encryptedValue
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	strToEncrypt = IDataUtil.getString( pipelineCursor, "strToEncrypt" );
			String	secret = IDataUtil.getString( pipelineCursor, "secret" );
		    pipelineCursor.destroy();
		    
		String encryptedValue = encrypt(strToEncrypt, secret);
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "encryptedValue", encryptedValue );
		pipelineCursor_1.destroy();	
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	public static String encrypt(String strToEncrypt, String secret)
	{
	    try
	    {
	        Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
	        cipher.init(Cipher.ENCRYPT_MODE, setKey(secret));
	        return Base64.getEncoder().encodeToString(cipher.doFinal(strToEncrypt.getBytes("UTF-8")));
	    }
	    catch (Exception e)
	    {
	       e.printStackTrace();
	    }
	    return null;
	}
	
	public static String decrypt(String strToDecrypt, String secret)
	{
	    try
	    {
	        Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5PADDING");
	        cipher.init(Cipher.DECRYPT_MODE, setKey(secret));
	        return new String(cipher.doFinal(Base64.getDecoder().decode(strToDecrypt)));
	    }
	    catch (Exception e)
	    {
	       e.printStackTrace();
	    }
	    return null;
	}
	
	public static SecretKeySpec setKey(String myKey)
	{
	    SecretKeySpec secretKey = null;
	    byte[] key;
	    MessageDigest sha = null;
	    try {
	               key = myKey.getBytes("UTF-8");
	               sha = MessageDigest.getInstance("SHA-1");
	               key = sha.digest(key);
	               key = Arrays.copyOf(key, 16);
	               secretKey = new SecretKeySpec(key, "AES");
	        }
	    catch (NoSuchAlgorithmException e) {
	        e.printStackTrace();
	    }
	    catch (UnsupportedEncodingException e) {
	        e.printStackTrace();
	    }
	    return secretKey;
	}	
	// --- <<IS-END-SHARED>> ---
}

