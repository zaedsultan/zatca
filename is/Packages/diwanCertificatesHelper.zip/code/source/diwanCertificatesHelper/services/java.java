package diwanCertificatesHelper.services;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.util.UUID;
// --- <<IS-END-IMPORTS>> ---

public final class java

{
	// ---( internal utility methods )---

	final static java _instance = new java();

	static java _newInstance() { return new java(); }

	static java _cast(Object o) { return (java)o; }

	// ---( server methods )---




	public static final void createGUID (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(createGUID)>> ---
		// @sigtype java 3.5
		// [o] field:0:required guid
		// pipeline
		
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		
		UUID uuid = UUID.randomUUID();
		String uuidStr = uuid.toString();
		IDataUtil.put( pipelineCursor, "guid",uuidStr );
		
		
		pipelineCursor.destroy();
			
		// --- <<IS-END>> ---

                
	}
}

