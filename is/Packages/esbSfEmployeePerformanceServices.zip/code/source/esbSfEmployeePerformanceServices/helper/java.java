package esbSfEmployeePerformanceServices.helper;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.util.Base64;
import java.util.Locale;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.Date;
// --- <<IS-END-IMPORTS>> ---

public final class java

{
	// ---( internal utility methods )---

	final static java _instance = new java();

	static java _newInstance() { return new java(); }

	static java _cast(Object o) { return (java)o; }

	// ---( server methods )---




	public static final void convertEpochTime (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(convertEpochTime)>> ---
		// @sigtype java 3.5
		// [i] field:0:required epochTime
		// [o] field:0:required dateTimeStamp
		//=================================================
		
								IDataCursor pipelineCursor = pipeline.getCursor();
		
				String epochTime = (String) IDataUtil.get(pipelineCursor, "epochTime");
		
				//long unix_seconds = 1563370941;  
		
				long unix_seconds = Long.parseLong(epochTime);
		
				//convert seconds to milliseconds
				  
				Date date = new Date(unix_seconds * 1000L);
		
				// format of the date  
		
				SimpleDateFormat jdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		
				String java_date = jdf.format(date);
		
				//System.out.println("\n" + java_date + "\n");
		
				IDataUtil.put(pipelineCursor, "dateTimeStamp", java_date);
		
				pipelineCursor.destroy();
				
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	
	public static String encryptHelper(String plaintext, String secretKey, String initializationVector) throws Exception {
	    SecretKeySpec key = new SecretKeySpec(secretKey.getBytes("UTF-8"), "AES");
	    IvParameterSpec iv = new IvParameterSpec(initializationVector.getBytes("UTF-8"));
	    Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5PADDING");
	    cipher.init(Cipher.ENCRYPT_MODE, key, iv);
	    byte[] encryptedBytes = cipher.doFinal(plaintext.getBytes());
	    return Base64.getEncoder().encodeToString(encryptedBytes);
	}
	
	public static String decryptHelper(String ciphertext, String secretKey, String initializationVector) throws Exception {
	    SecretKeySpec key = new SecretKeySpec(secretKey.getBytes("UTF-8"), "AES");
	    IvParameterSpec iv = new IvParameterSpec(initializationVector.getBytes("UTF-8"));
	    Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5PADDING");
	    cipher.init(Cipher.DECRYPT_MODE, key, iv);
	    byte[] ciphertextBytes = Base64.getDecoder().decode(ciphertext);
	    byte[] decryptedBytes = cipher.doFinal(ciphertextBytes);
	    return new String(decryptedBytes);
	}
	
		
	// --- <<IS-END-SHARED>> ---
}

