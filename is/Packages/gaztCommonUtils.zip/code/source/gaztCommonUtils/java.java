package gaztCommonUtils;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.util.ArrayList;
import java.util.stream.Collectors;
import java.text.ParseException;
import java.util.*;
import com.ibm.icu.text.SimpleDateFormat;
import com.softwareag.is.log.Log;
// --- <<IS-END-IMPORTS>> ---

public final class java

{
	// ---( internal utility methods )---

	final static java _instance = new java();

	static java _newInstance() { return new java(); }

	static java _cast(Object o) { return (java)o; }

	// ---( server methods )---




	public static final void castToInt (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(castToInt)>> ---
		// @sigtype java 3.5
		// [i] field:0:required string
		// [o] object:0:required int
		IDataCursor cursor = pipeline.getCursor();
		String inputString = IDataUtil.getString(cursor, "string");
			
		int outputInt = Integer.parseInt(inputString.trim());
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "int", outputInt );
			
		// --- <<IS-END>> ---

                
	}



	public static final void castToLong (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(castToLong)>> ---
		// @sigtype java 3.5
		// [i] field:0:required string
		// [o] object:0:required int
		IDataCursor cursor = pipeline.getCursor();
		String inputString = IDataUtil.getString(cursor, "string");
			
		Long outputInt = (long) Integer.parseInt(inputString.trim());
		
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "int", outputInt );
			
		// --- <<IS-END>> ---

                
	}



	public static final void getMembersByRoleId (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getMembersByRoleId)>> ---
		// @sigtype java 3.5
		// [i] field:0:required roleId
		// [o] field:1:required roleMembers
		final IDataCursor cursor = pipeline.getCursor();
		final String string = IDataUtil.getString(cursor, "roleId");
		//final String string2 = IDataUtil.getString(cursor, "memberType");
		cursor.destroy();
		final ArrayList<String> list = new ArrayList<String>();
		try {
		
		IDirectorySession role = DirectorySystemFactory.getDirectorySystem().createSession();
		
		    if (role == null) {
		        throw new ServiceException("A session to the server could not be established. Please contact an Administrator");
		    }
		    final IDirectoryPrincipal lookupPrincipalByName = role.lookupPrincipalByName(string, 2);
		    
		    //System.out.println("role id is "+role);
		    
		    //System.out.println("lookupPrincipalByName id is "+lookupPrincipalByName);
		    
		    if (lookupPrincipalByName == null) {
		        throw new ServiceException("Role not found. Please make sure to provide a name of an existing role!");
		    }
		    final List <IDirectoryPrincipal> members = role.getMembers(lookupPrincipalByName.getID());
		           
		 
		    for (int i = 0; i < members.size(); ++i) {
		        final IDirectoryPrincipal directoryPrincipal = members.get(i);
		        
		
		            if (directoryPrincipal.getType() == 0) {
		            	
		                list.add(directoryPrincipal.getName());
		                
		            }
		    }
		}
		catch (DirectoryException ex) {
		    throw new ServiceException(ex.getMessage());
		}
		catch (NullPointerException ex2) {
		    throw new ServiceException("Problems found while looking for membership of role " + string);
		}
		final String[] array2 = list.toArray(new String[list.size()]);
		final IDataCursor cursor2 = pipeline.getCursor();
		IDataUtil.put(cursor2, "roleMembers", (Object)array2);
		cursor2.destroy();
		
		
			
		// --- <<IS-END>> ---

                
	}



	public static final void isRoleExist (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(isRoleExist)>> ---
		// @sigtype java 3.5
		// [i] field:0:required roleName
		// [o] field:0:required status
		IDataCursor pipelineCursor = pipeline.getCursor();
		String	roleName = IDataUtil.getString( pipelineCursor, "roleName" );
		
		IDirectorySession s = DirectorySystemFactory.getDirectorySystem().createSession();
		
		String status = "false";
		
		try{
			IDirectoryRole myRole = (IDirectoryRole) s.lookupPrincipalByName(roleName, IDirectoryPrincipal.TYPE_ROLE);
			if (myRole == null)
			{
			}
			else{
				status = "true";
			}
			
			// pipeline out
			IDataCursor pipelineCursor_1 = pipeline.getCursor();
			IDataUtil.put( pipelineCursor_1, "status", status );
			pipelineCursor_1.destroy();
			
			DirectorySystemFactory.getDirectorySystem().destroySession(s);
			
		}
			catch(Exception E){
				Log.debug("gaztCommonUtils.java:isRoleExist, Error: Failed to retrieve role name: " + roleName 
						+ " , Message: "  + E.toString());	
				// pipeline out
				IDataCursor pipelineCursor_1 = pipeline.getCursor();
				IDataUtil.put( pipelineCursor_1, "status", status );
				pipelineCursor_1.destroy();
				DirectorySystemFactory.getDirectorySystem().destroySession(s);
						
			}
		// --- <<IS-END>> ---

                
	}
}

