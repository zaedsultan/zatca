package ESBConfigurationManagement.common.services;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2016-04-05 09:02:16 AST
// -----( ON-HOST: SS-JHQ-WMDEV.SABICCORP.SABIC.com

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.io.*;
import java.util.*;
// --- <<IS-END-IMPORTS>> ---

public final class propertyFile

{
	// ---( internal utility methods )---

	final static propertyFile _instance = new propertyFile();

	static propertyFile _newInstance() { return new propertyFile(); }

	static propertyFile _cast(Object o) { return (propertyFile)o; }

	// ---( server methods )---




	public static final void loadProperties (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(loadProperties)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required fileName
		    /*
		        Retrieves values from configFile
		        directory [server]/packages/yourPackage/config/
		    */
		
		IDataCursor pipelineCursor = pipeline.getCursor();
		CONFIG_FILE = IDataUtil.getString( pipelineCursor, "fileName" );
		
		
		
		    try{
			// read in the file stream and convert it to a properties object
		        FileInputStream configFileInputStream = new FileInputStream( CONFIG_FILE );
		
			// properties object is already defined in the Shared code
		        properties = new Properties();
		        properties.load( configFileInputStream );
			propertiesLoaded = true;
		
			// register configFile
			IData pipeRegister = IDataFactory.create();
			IDataUtil.put(pipeRegister.getCursor(), "configFile", CONFIG_FILE);
			Service.doInvoke("ESBConfigurationManagement.propertyFile.admin", "registerPropertyFile", pipeRegister);
		
		    }catch ( FileNotFoundException e ){
		        // throw an error
			throw new ServiceException("Error finding property file: "+e);
		    }catch ( IOException e ){
		        //throw an error
			throw new ServiceException("Error reading "+CONFIG_FILE+" property file: "+e);
		    }catch ( Exception e ){
		        //throw an error
			throw new ServiceException("Error while registering "+CONFIG_FILE+" property file: "+e);
		    }
			
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	// initialize static variables

 
	private static String CONFIG_FILE;
    private static boolean propertiesLoaded = false;
    private static Properties properties = null;

    /** gets a property from the config file **/
    public static String getProperty( String key ) throws ServiceException
    {
		// check to see if the properties have been loaded
        if (!propertiesLoaded) {
			try{
				IData idata = IDataFactory.create();
				IDataUtil.put(idata.getCursor(),"configFile",CONFIG_FILE);
            	loadProperties( idata );
			}catch (Exception e){
				throw new ServiceException("Failed to load properties:"+e.toString());
			}
        }
        if ( properties == null )
            return( null );
        else
            return( properties.getProperty( key ) );
    }
	
	// --- <<IS-END-SHARED>> ---
}

