package ESBConfigurationManagement.propertyFile;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2016-04-07 13:47:16 AST
// -----( ON-HOST: SS-JHQ-WMDEV.SABICCORP.SABIC.com

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.util.Set;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.MessageFormat;
import java.util.TreeSet;
import com.wm.app.b2b.server.InvokeState;
// --- <<IS-END-IMPORTS>> ---

public final class admin

{
	// ---( internal utility methods )---

	final static admin _instance = new admin();

	static admin _newInstance() { return new admin(); }

	static admin _cast(Object o) { return (admin)o; }

	// ---( server methods )---




	public static final void getPropertyFileList (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getPropertyFileList)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [o] field:1:required propertyFileList
		if (PROPERTY_FILES != null) {
			IDataCursor pc = pipeline.getCursor();
			IDataUtil.put( pc, "propertyFileList", PROPERTY_FILES.toArray(new String[0]));
			pc.destroy();
		}
		// --- <<IS-END>> ---

                
	}



	public static final void isAccessReadOnly (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(isAccessReadOnly)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [o] field:0:required readonly
		boolean rdOnly = InvokeState.getCurrentUser().isAdministrator();
		IDataCursor pc = pipeline.getCursor();
		IDataUtil.put(pc, "readonly", String.valueOf(!rdOnly));
		pc.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void readPropertyFile (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(readPropertyFile)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required configFile
		// [o] field:0:required data
		
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		String	configFile = IDataUtil.getString( pipelineCursor, "configFile" );
		if( configFile == null ){
			throw new ServiceException("No file selected");
		}
		pipelineCursor.destroy();
		String data = "";
		
			try{
				FileInputStream fis = new FileInputStream(configFile);
				byte[] dataArray = new byte[fis.available()];
				// file reading
				fis.read(dataArray);
				fis.close();
				data = new String( dataArray );
			}catch(Exception e){
				throw new ServiceException("Failed to read "+configFile+" : "+e.toString());
			}
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "data", data );
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void registerPropertyFile (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(registerPropertyFile)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required configFile
		
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		String configFile = IDataUtil.getString(pipelineCursor, "configFile");
		pipelineCursor.destroy();
		if( configFile != null ) {
			if(PROPERTY_FILES == null) {
				PROPERTY_FILES = new TreeSet();
			}
			if(!checkExistence(configFile)) {
				PROPERTY_FILES.add(configFile);
			}
		}
		// --- <<IS-END>> ---

                
	}



	public static final void updatePropertyFile (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(updatePropertyFile)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required configFile
		// [i] field:0:required data
		// [o] field:0:required message0
		// [o] field:0:required message1
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		String	configFile = IDataUtil.getString( pipelineCursor, "configFile" );
		CONFIG_FILE = IDataUtil.getString( pipelineCursor, "configFile" );
		String	data = IDataUtil.getString( pipelineCursor, "data" );
		String message0 = "";
		String message1 = "";
		
			try{
				FileOutputStream fos = new FileOutputStream(configFile);
				fos.write( data.getBytes() );
				fos.flush();
				fos.close();
				message0 = "Property file "+configFile+" updated";
			}catch(Exception e){
				message0 = "Failed to change "+configFile+" : "+e.toString();
			}
		
			try{
		//				MessageFormat msgFormat = new MessageFormat( "{0}packages/{1}/{2}" );
		//				Object[] args = msgFormat.parse(configFile);
		//						if( (args==null) || (args.length!=3) ){
		//							message1 = "Failed to retrieve concerned package name";
		//						}else
				{
		//					String packageName = (String)args[1];
		//							IData pipeRegister = IDataFactory.create();
		//							IDataUtil.put(pipeRegister.getCursor(), "configFile", CONFIG_FILE);
							Service.doInvoke("ESBConfigurationManagement.common.services.startup", "loadProperties",null );
							Service.doInvoke("ESBConfigurationManagement.common.services.propertyFile", "loadSabicCache",null );
		
							//					message1 = "properties of package "+packageName+" are reloaded";
					message1 = "Sabic Cache and properties are reloaded";
				}
			}catch(Exception e){
												message1 = "Failed to reload sabic cache or properties  : "+e.toString();
			}
		
		// pipeline
		IDataUtil.put( pipelineCursor, "message0", message0 );
		IDataUtil.put( pipelineCursor, "message1", message1 );
		pipelineCursor.destroy();
			
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	private static Set PROPERTY_FILES;
	private static String CONFIG_FILE;
	private static boolean checkExistence(String configFile) {
		if (PROPERTY_FILES == null) return false;
		if (configFile == null) return false;
		return PROPERTY_FILES.contains(configFile.trim());
	}
		
	// --- <<IS-END-SHARED>> ---
}

