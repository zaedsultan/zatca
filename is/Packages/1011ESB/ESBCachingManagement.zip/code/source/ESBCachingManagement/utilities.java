package ESBCachingManagement;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
// --- <<IS-END-IMPORTS>> ---

public final class utilities

{
	// ---( internal utility methods )---

	final static utilities _instance = new utilities();

	static utilities _newInstance() { return new utilities(); }

	static utilities _cast(Object o) { return (utilities)o; }

	// ---( server methods )---




	public static final void mapCachedConfigurations (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(mapCachedConfigurations)>> ---
		// @sigtype java 3.5
		// [i] record:1:required elements
		// [i] - field:0:required key
		// [i] - field:0:required value
		// [o] record:0:required Configurations
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		
			// elements
			IData[]	elements = IDataUtil.getIDataArray( pipelineCursor, "elements" );
			
			// pipeline
			IDataCursor pipelineCursor_1 = pipeline.getCursor();
		
			// Configurations 
			IData	Configurations = IDataFactory.create();
			IDataCursor configurationsCursor = Configurations.getCursor();
			
			if ( elements != null)
			{
				for ( int i = 0; i < elements.length; i++ )
				{
					IDataCursor elementsCursor = elements[i].getCursor();
						String	key = IDataUtil.getString( elementsCursor, "key" );
						String	value = IDataUtil.getString( elementsCursor, "value" );
						int lastIndexOfKey = key.lastIndexOf(".");
						String keyParam = key.substring(lastIndexOfKey+1, key.length());
						IDataUtil.put(configurationsCursor, keyParam, value);
					elementsCursor.destroy();
				}
			}
			
			configurationsCursor.destroy();
		pipelineCursor.destroy();
		
		
		IDataUtil.put( pipelineCursor_1, "Configurations", Configurations );
		pipelineCursor_1.destroy();
			
		// --- <<IS-END>> ---

                
	}
}

