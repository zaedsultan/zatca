PACKAGE_PATH="/sag/softwareag1011/IntegrationServer/instances/Diwan_ESB/packages"
FILE_PATH_WORKING=$PACKAGE_PATH"/esbPackageBuilder/resources/folders/working"
FILE_PATH_DONE=$PACKAGE_PATH"/"
SKELETON_PACKAGE="esbSkeletonConnections"
MODULE_NAME="SERVICE_NAME"
SKELETON_PACKAGE_PATH=$PACKAGE_PATH"/"$SKELETON_PACKAGE	
SK_GET_OPS="GET_OPS"
SK_POST_OPS="POST_OPS"
GET_OPS_Value=$3
POST_OPS_Value=$4
if [ -d $FILE_PATH_WORKING"/" ]
then
        rm -r $FILE_PATH_WORKING"/"
fi

mkdir $FILE_PATH_WORKING

echo "Copy skeleton package"
cp -avr $SKELETON_PACKAGE_PATH $FILE_PATH_WORKING/
find $FILE_PATH_WORKING -type f | xargs sed -i  's/'$SKELETON_PACKAGE'/'$1'/g'
echo "---------Step 1.0 -----------"$2
find $FILE_PATH_WORKING/ -name \*.* -exec sed -i "s/"$MODULE_NAME"/"$2"/g" {} \;
echo "---------Step 1.1 repalce file names GET_OPS -----------"$2
find $FILE_PATH_WORKING/ -name \*.* -exec sed -i "s/"$SK_GET_OPS"/"$GET_OPS_Value"/g" {} \;
echo "---------Step 1.2 repalce file names POST_OPS -----------"$2
find $FILE_PATH_WORKING/ -name \*.* -exec sed -i "s/"$SK_POST_OPS"/"$POST_OPS_Value"/g" {} \;
echo "---------Step 2 -----------"$1
for f1 in $FILE_PATH_WORKING/* ; do mv "$f1" "$(echo "$f1" | sed s/"$SKELETON_PACKAGE"/"$1"/)"; done
echo "---------Step 3 -----------"
for f1 in $FILE_PATH_WORKING/$1/ns/* ; do mv "$f1" "$(echo "$f1" | sed s/"$SKELETON_PACKAGE"/"$1"/)"; done
echo "---------Step 4 -----------"
for f1 in $FILE_PATH_WORKING/$1/ns/$1/v01/services/* ; do mv "$f1" "$(echo "$f1" | sed s/"$MODULE_NAME"/"$2"/)"; done
echo "---------Step 4.1 -----------"
for f1 in $FILE_PATH_WORKING/$1/ns/$1/v01/services/* ; do mv "$f1" "$(echo "$f1" | sed s/"$MODULE_NAME"/"$2"/)"; done
for f1 in $FILE_PATH_WORKING/$1/ns/$1/v01/services/* ; do mv "$f1" "$(echo "$f1" | sed s/"$MODULE_NAME"/"$2"/)"; done
echo "---------Step 5 -----------"
for f1 in $FILE_PATH_WORKING/$1/ns/$1/v01/services/$2/restful/* ; do mv "$f1" "$(echo "$f1" | sed s/"$MODULE_NAME"/"$2"/)"; done
echo "---------Step 5.1 -----------"
for f1 in $FILE_PATH_WORKING/$1/ns/$1/v01/services/$2/restful/* ; do mv "$f1" "$(echo "$f1" | sed s/"$SK_GET_OPS"/"$GET_OPS_Value"/)"; done
for f1 in $FILE_PATH_WORKING/$1/ns/$1/v01/services/$2/restful/* ; do mv "$f1" "$(echo "$f1" | sed s/"$SK_POST_OPS"/"$POST_OPS_Value"/)"; done
echo "---------Step 6 -----------"
for f1 in $FILE_PATH_WORKING/$1/ns/$1/v01/services/$2/restful/$2_/docTypes/* ; do mv "$f1" "$(echo "$f1" | sed s/"$MODULE_NAME"/"$2"/)"; done
echo "---------Step 6.1 -----------"
for f1 in $FILE_PATH_WORKING/$1/ns/$1/v01/services/$2/operations/* ; do mv "$f1" "$(echo "$f1" | sed s/"$SK_GET_OPS"/"$GET_OPS_Value"/)"; done
for f1 in $FILE_PATH_WORKING/$1/ns/$1/v01/services/$2/operations/* ; do mv "$f1" "$(echo "$f1" | sed s/"$SK_POST_OPS"/"$POST_OPS_Value"/)"; done
echo "---------Step 7 -----------"
for f1 in $FILE_PATH_WORKING/$1/ns/$1/v01/doc/* ; do mv "$f1" "$(echo "$f1" | sed s/"$MODULE_NAME"/"$2"/)"; done
echo "---------Step 7.1 -----------"
for f1 in $FILE_PATH_WORKING/$1/ns/$1/v01/doc/* ; do mv "$f1" "$(echo "$f1" | sed s/"$SK_GET_OPS"/"$GET_OPS_Value"/)"; done
for f1 in $FILE_PATH_WORKING/$1/ns/$1/v01/doc/* ; do mv "$f1" "$(echo "$f1" | sed s/"$SK_POST_OPS"/"$POST_OPS_Value"/)"; done

cp -avr $FILE_PATH_WORKING/* $FILE_PATH_DONE

if [ -d $FILE_PATH_WORKING"/" ]
then
        rm -r $FILE_PATH_WORKING"/"
fi

mkdir $FILE_PATH_WORKING
