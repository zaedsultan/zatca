package ESBCommon_1.v01.utils;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import com.softwareag.util.IDataArray;
import com.softwareag.util.IDataMap;
import com.wm.app.b2b.server.InvokeState;
import com.wm.app.b2b.server.User;
import java.io.IOException;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import com.wm.data.IData;
import com.wm.data.IDataCursor;
import com.wm.data.IDataUtil;
import com.wm.lang.ns.NSName;
import java.util.*;
import com.wm.app.b2b.server.*;
import java.time.LocalDate;
import java.time.Period;
import java.time.ZoneId;
import java.time.chrono.HijrahChronology;
import java.time.chrono.HijrahDate;
import java.time.chrono.IsoChronology;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAccessor;
// --- <<IS-END-IMPORTS>> ---

public final class java

{
	// ---( internal utility methods )---

	final static java _instance = new java();

	static java _newInstance() { return new java(); }

	static java _cast(Object o) { return (java)o; }

	// ---( server methods )---




	public static final void convertNumToString (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(convertNumToString)>> ---
		// @sigtype java 3.5
		// [i] object:0:required input
		// [o] field:0:required output
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			Object	input = IDataUtil.get( pipelineCursor, "input" );
		pipelineCursor.destroy();  
		
		
		String output = input.toString(); 
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor(); 
		IDataUtil.put( pipelineCursor_1, "output", output );
		pipelineCursor_1.destroy();  
		
			 
			
		// --- <<IS-END>> ---

                
	}



	public static final void convertStringToDate (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(convertStringToDate)>> ---
		// @sigtype java 3.5
		// [i] field:0:required dateString
		// [i] field:0:required dateFormat
		// [o] object:0:required formattedDate
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	dateString = IDataUtil.getString( pipelineCursor, "dateString" );
			String	dateFormat = IDataUtil.getString( pipelineCursor, "dateFormat" );
		pipelineCursor.destroy();
		
		SimpleDateFormat sdf = new SimpleDateFormat(dateFormat); 
		Date date; 
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		Object formattedDate = new Object();
		try 
		{ 
		date = sdf.parse(dateString); 
		IDataUtil.put(pipelineCursor_1, "formattedDate", date); 
		} 
		catch (ParseException pe) 
		{ 
		throw new ServiceException("Date '" + dateString + 
		"' cannot be parsed using the format '" + dateFormat + "'"); 
		} 
		
		// pipeline
		
		pipelineCursor_1.destroy();
			
		// --- <<IS-END>> ---

                
	}



	public static final void convertStringToNum (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(convertStringToNum)>> ---
		// @sigtype java 3.5
		// [i] field:0:required input
		// [o] object:0:required output
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		String	input = IDataUtil.getString( pipelineCursor, "input" );
		pipelineCursor.destroy();
		
		double output = Double.parseDouble(input);
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		//Object output = new Object();
		IDataUtil.put( pipelineCursor_1, "output", output );
		pipelineCursor_1.destroy();
			
		// --- <<IS-END>> ---

                
	}



	public static final void createCache (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(createCache)>> ---
		// @sigtype java 3.5
		// [i] field:0:required cacheManagerName
		// [i] field:0:required cacheName
		// [i] field:0:required timeToIdleSeconds
		// [i] field:0:required timeToLiveSeconds
		// [i] field:0:required maxElementsInMemory
		// [i] field:0:required maxEntriesLocalDisk
		// [i] field:0:required maxEntriesInCache
		// [i] field:0:required logging
		// [i] field:0:required clearOnFlush
		// [i] field:0:required copyOnRead
		// [i] field:0:required copyOnWrite
		// [i] field:0:required overflowToDisk
		// [i] field:0:required overflowToOffHeap
		// [i] field:0:required maxMemoryOffHeap
		// [i] field:0:required memoryStoreEvictionPolicy
		// [i] field:0:required diskExpiryThreadIntervalSeconds
		// [i] field:0:required diskPersistent
		// [i] field:0:required diskSpoolBufferSizeMB
		// [i] field:0:required eternal
		// [i] field:0:required diskAccessStripes
		// [i] field:0:required cacheLoaderTimeoutMillis
		// [i] record:0:optional terracottaConfiguration
		// [i] - field:0:optional clustered
		// [i] - field:0:optional consistency
		// [i] - field:0:optional synchronousWrites
		// [i] - field:0:optional storageStrategy
		// [i] - record:0:optional nonStopConfiguration
		// [i] -- field:0:optional timeoutBehaviorType
		// [i] -- field:0:optional timeoutBehaviorProperties
		// [i] -- field:0:optional timeoutBehaviorPropertySeparator
		// [i] -- field:0:optional enabled
		// [i] -- field:0:optional immediateTimeout
		// [i] -- field:0:optional timeoutMillis
		// [o] field:0:required status
		// [o] field:0:required message
		
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	cacheManagerName = IDataUtil.getString( pipelineCursor, "cacheManagerName" );
			String	cacheName = IDataUtil.getString( pipelineCursor, "cacheName" );
			String	timeToIdleSeconds = IDataUtil.getString( pipelineCursor, "timeToIdleSeconds" );
			String	timeToLiveSeconds = IDataUtil.getString( pipelineCursor, "timeToLiveSeconds" );
			String	maxElementsInMemory = IDataUtil.getString( pipelineCursor, "maxElementsInMemory" );
			String	maxEntriesLocalDisk = IDataUtil.getString( pipelineCursor, "maxEntriesLocalDisk" );
			String	maxEntriesInCache = IDataUtil.getString( pipelineCursor, "maxEntriesInCache" );
			String	logging = IDataUtil.getString( pipelineCursor, "logging" );
			String	clearOnFlush = IDataUtil.getString( pipelineCursor, "clearOnFlush" );
			String	copyOnRead = IDataUtil.getString( pipelineCursor, "copyOnRead" );
			String	copyOnWrite = IDataUtil.getString( pipelineCursor, "copyOnWrite" );
			String	overflowToDisk = IDataUtil.getString( pipelineCursor, "overflowToDisk" );
			String	overflowToOffHeap = IDataUtil.getString( pipelineCursor, "overflowToOffHeap" );
			String	maxMemoryOffHeap = IDataUtil.getString( pipelineCursor, "maxMemoryOffHeap" );
			String	memoryStoreEvictionPolicy = IDataUtil.getString( pipelineCursor, "memoryStoreEvictionPolicy" );
			String	diskExpiryThreadIntervalSeconds = IDataUtil.getString( pipelineCursor, "diskExpiryThreadIntervalSeconds" );
			String	diskPersistent = IDataUtil.getString( pipelineCursor, "diskPersistent" );
			String	diskSpoolBufferSizeMB = IDataUtil.getString( pipelineCursor, "diskSpoolBufferSizeMB" );
			String	eternal = IDataUtil.getString( pipelineCursor, "eternal" );
			String	diskAccessStripes = IDataUtil.getString( pipelineCursor, "diskAccessStripes" );
			String	cacheLoaderTimeoutMillis = IDataUtil.getString( pipelineCursor, "cacheLoaderTimeoutMillis" );
		
			// terracottaConfiguration
			IData	terracottaConfiguration = IDataUtil.getIData( pipelineCursor, "terracottaConfiguration" );
			if ( terracottaConfiguration != null)
			{
				IDataCursor terracottaConfigurationCursor = terracottaConfiguration.getCursor();
					String	clustered = IDataUtil.getString( terracottaConfigurationCursor, "clustered" );
					String	consistency = IDataUtil.getString( terracottaConfigurationCursor, "consistency" );
					String	synchronousWrites = IDataUtil.getString( terracottaConfigurationCursor, "synchronousWrites" );
					String	storageStrategy = IDataUtil.getString( terracottaConfigurationCursor, "storageStrategy" );
		
					// i.nonStopConfiguration
					IData	nonStopConfiguration = IDataUtil.getIData( terracottaConfigurationCursor, "nonStopConfiguration" );
					if ( nonStopConfiguration != null)
					{
						IDataCursor nonStopConfigurationCursor = nonStopConfiguration.getCursor();
							String	timeoutBehaviorType = IDataUtil.getString( nonStopConfigurationCursor, "timeoutBehaviorType" );
							String	timeoutBehaviorProperties = IDataUtil.getString( nonStopConfigurationCursor, "timeoutBehaviorProperties" );
							String	timeoutBehaviorPropertySeparator = IDataUtil.getString( nonStopConfigurationCursor, "timeoutBehaviorPropertySeparator" );
							String	enabled = IDataUtil.getString( nonStopConfigurationCursor, "enabled" );
							String	immediateTimeout = IDataUtil.getString( nonStopConfigurationCursor, "immediateTimeout" );
							String	timeoutMillis = IDataUtil.getString( nonStopConfigurationCursor, "timeoutMillis" );
						nonStopConfigurationCursor.destroy();
					}
				terracottaConfigurationCursor.destroy();
			}
		pipelineCursor.destroy();
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "status", "status" );
		IDataUtil.put( pipelineCursor_1, "message", "message" );
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void getContextStack (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getContextStack)>> ---
		// @sigtype java 3.5
		// [o] field:1:required contextStack
		// [o] field:0:required currentParentID
		// [o] field:0:required currentRootID
		IDataCursor idc = pipeline.getCursor();
		String[] contextStack;
		String currentContextID = "";
		String currentParentID = "";
		String currentRootID = "";
		try{
		                contextStack = InvokeState.getCurrentState().getAuditRuntime().getContextStack();
		                if(contextStack!=null)
		                                if(contextStack.length >=3){
		                                                currentRootID = contextStack[0];
		                                                currentParentID = contextStack[1];
		                                                currentContextID = contextStack[2];
		                                }else if (contextStack.length>=2){
		                                                                currentRootID = contextStack[0];
		                                                                currentParentID = contextStack[1];
		                                                                currentContextID = currentParentID;
		                                }else if (contextStack.length>=1){
		                                                                currentRootID = contextStack[0];
		                                                                currentParentID = currentRootID;
		                                                                currentContextID = currentRootID;
		                                }
		}catch(Exception ex){
		                ServiceException sx = new ServiceException(ex);
		                throw sx;
		}
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put(pipelineCursor_1, "currentContextID", currentParentID); // Assuming that caller is looking for its context ID. currentContextID extracted is the context ID for the java service, not the caller service.
		IDataUtil.put(idc, "contextStack", contextStack);
		IDataUtil.put(idc, "currentRootID", currentRootID);
		idc.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void getCurrentUser (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getCurrentUser)>> ---
		// @sigtype java 3.5
		// [o] field:0:required currentUser
		String currentUser = InvokeState.getCurrentState().getUser()+"";
		// pipeline
				IDataCursor pipelineCursor_1 = pipeline.getCursor();
				IDataUtil.put( pipelineCursor_1, "currentUser", currentUser );
								pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void getIdentity (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getIdentity)>> ---
		// @sigtype java 3.5
		// [o] field:0:required serviceName
		// [o] field:0:required packageName
		// [o] field:0:required unQualifiedServiceName
		// pipeline
		String serviceName = Service.getCallingService().toString();
		String unQualifiedServiceName = serviceName.split(":")[1];
		String packageName = serviceName.split("\\.")[0];
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		IDataUtil.put( pipelineCursor, "serviceName",serviceName);
		IDataUtil.put( pipelineCursor, "packageName",packageName);
		IDataUtil.put( pipelineCursor, "unQualifiedServiceName",unQualifiedServiceName);
		pipelineCursor.destroy(); 
			
			
		// --- <<IS-END>> ---

                
	}



	public static final void getInstallationDir (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getInstallationDir)>> ---
		// @sigtype java 3.5
		// [o] field:0:required installationDir
		// pipeline
		
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		IDataUtil.put( pipelineCursor, "installationDir", System.getProperty("user.dir") );
		pipelineCursor.destroy(); 
		 
			
		// --- <<IS-END>> ---

                
	}



	public static final void getNull (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getNull)>> ---
		// @sigtype java 3.5
		// [o] object:0:required resNull
		// pipeline
		
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		Object resNull = null;
		IDataUtil.put( pipelineCursor, "resNull", resNull );
		pipelineCursor.destroy();
			
		// --- <<IS-END>> ---

                
	}



	public static final void getServiceStack (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getServiceStack)>> ---
		// @sigtype java 3.5
		// [o] field:0:required rootService
		// [o] field:1:required serviceStack
		IDataCursor idc = pipeline.getCursor();
		@SuppressWarnings("rawtypes")
		Stack callStack = com.wm.app.b2b.server.InvokeState.getCurrentState().getCallStack();
		 
		// Note that we allocated one less than what the stack has
		// to omit this service from being in the list
		String[] serviceStack = new String[callStack.size()-1];
		String rootService = ((com.wm.lang.ns.NSService)callStack.elementAt(0)).toString(); 
		for(int j=0,i=serviceStack.length; --i>=0;j++)
		serviceStack[j] = ((com.wm.lang.ns.NSService)callStack.elementAt(i)).toString();
		
		IDataUtil.put(idc, "serviceStack", serviceStack);
		IDataUtil.put(idc, "rootService", rootService);
		idc.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void getSystemProperty (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getSystemProperty)>> ---
		// @sigtype java 3.5
		// [i] field:0:required propertyName
		// [o] field:0:required property
		/**
		 * Service is designed to return the specified system property.
		 * 
		 */ 
		
		IDataCursor hCursor = pipeline.getCursor(); 
		
		hCursor.first("propertyName");
		String propertyName = (String) hCursor.getValue();
		
		String property = new String();
		
		property = System.getProperty(propertyName, "No property found");
		
		if (hCursor.first("property"))
		  hCursor.delete();
		hCursor.insertAfter("property", property);
			
		// --- <<IS-END>> ---

                
	}



	public static final void isFileExists (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(isFileExists)>> ---
		// @sigtype java 3.5
		// [i] field:0:required pathname
		// [o] field:0:required isPathExists
		// [o] field:0:required isDirectory
		IDataCursor idcPipeline = pipeline.getCursor();
		String strPathname = "";
		if (idcPipeline.first("pathname"))
		{
		  strPathname = (String) idcPipeline.getValue();
		  File path = new File(strPathname);
		
		  // *** Check if path is on the allowed list ***
		 
		  // *** End check *** 
		
		  if (!path.exists())
		    idcPipeline.insertAfter("isPathExists", "false"); 
		  else
		    idcPipeline.insertAfter("isPathExists", "true");
		
		  if (path.isDirectory())
		    idcPipeline.insertAfter("isDirectory", "true");
		  else
		    idcPipeline.insertAfter("isDirectory", "false");
		}
		else
		{
		  idcPipeline.insertAfter("isPathExists", "false");
		  idcPipeline.insertAfter("isDirectory", "false");
		}
		
		idcPipeline.destroy();
			
		// --- <<IS-END>> ---

                
	}



	public static final void multiConcat (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(multiConcat)>> ---
		// @sigtype java 3.5
		// [i] field:0:required inStr1
		// [i] field:0:required inStr2
		// [i] field:0:required inStr3
		// [i] field:0:required inStr4
		// [i] field:0:required inStr5
		// [i] field:0:required inStr6
		// [i] field:0:required inStr7
		// [i] field:0:required inStr8
		// [i] field:0:required inStr9
		// [i] field:0:required inStr10
		// [o] field:0:required outStr
		IDataCursor in = pipeline.getCursor();
		
		
		
		String str1 = checkNull(IDataUtil.getString(in, "inStr1"));
		String str2 = checkNull(IDataUtil.getString(in, "inStr2"));
		String str3 = checkNull(IDataUtil.getString(in, "inStr3"));
		String str4 = checkNull(IDataUtil.getString(in, "inStr4"));
		String str5 = checkNull(IDataUtil.getString(in, "inStr5"));
		String str6 = checkNull(IDataUtil.getString(in, "inStr6"));
		String str7 = checkNull(IDataUtil.getString(in, "inStr7"));
		String str8 = checkNull(IDataUtil.getString(in, "inStr8"));
		String str9 = checkNull(IDataUtil.getString(in, "inStr9"));
		String str10 = checkNull(IDataUtil.getString(in, "inStr10"));
		in.destroy();
		String outStr = str1 + str2 + str3 + str4 + str5 + str6 + str7 + str8 + str9 + str10;
		
		IDataCursor out = pipeline.getCursor();
		IDataUtil.put(out, "outStr", outStr);
		out.destroy();
			
			
		// --- <<IS-END>> ---

                
	}



	public static final void spawnService (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(spawnService)>> ---
		// @sigtype java 3.5
		// [i] field:0:required folder
		// [i] field:0:required service
		// [i] record:0:required inputs
		// [o] object:0:required serviceThread
		IDataCursor cursor = pipeline.getCursor();
		
		String service = null;
		String folder = null;
		IData inputs = null;
		
		if (cursor.first("service"))
		{ 
		  service = (String) cursor.getValue();
		}
		else
		{
		  throw new ServiceException("Missing input 'service'");
		}
		
		if (cursor.first("folder"))
		{
		  folder = (String) cursor.getValue();
		}
		else
		{
		  throw new ServiceException("Missing input 'interface'");
		}
		
		if (cursor.first("inputs"))
		{
		  inputs = (IData) cursor.getValue();
		}
		
		try
		{
		  ServiceThread serviceThread = Service.doThreadInvoke(folder, service, inputs);
		
		  if (cursor.first("serviceThread"))
		  {
		    cursor.setValue(serviceThread);
		  }
		  else
		  {
		    cursor.insertAfter("serviceThread", serviceThread);
		  }
		}
		catch (Exception e)
		{
		  throw new ServiceException(e);
		}
		finally
		{
		  cursor.destroy();
		}
			
		// --- <<IS-END>> ---

                
	}



	public static final void stringToDate (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(stringToDate)>> ---
		// @sigtype java 3.5
		// [i] field:0:required dateString
		// [o] field:0:required expireDate
		IDataCursor cursor = pipeline.getCursor(); 
		
		String dateFormat = "MM/dd/yyyy"; 
		String dateString = null; 
		
		if(cursor.first("dateString")) 
		{ 
		dateString = (String)cursor.getValue(); 
		} 
		else 
		{ 
		throw new ServiceException("Missing input 'date'"); 
		} 
		
		if (cursor.first("pattern")) 
		{ 
		dateFormat = (String)cursor.getValue(); 
		} 
		
		SimpleDateFormat sdf = new SimpleDateFormat(dateFormat); 
		Date date; 
		try 
		{ 
		date = sdf.parse(dateString); 
		IDataUtil.put(cursor, "expireDate", date); 
		} 
		catch (ParseException pe) 
		{ 
		throw new ServiceException("Date '" + dateString + 
		"' cannot be parsed using the format '" + dateFormat + "'"); 
		} 
		finally 
		{ 
		cursor.destroy(); 
		}
		// --- <<IS-END>> ---

                
	}



	public static final void throwError (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(throwError)>> ---
		// @sigtype java 3.5
		// [i] field:0:required errorMessage
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	errorMessage = IDataUtil.getString( pipelineCursor, "errorMessage" );
		pipelineCursor.destroy();
		
		// pipeline
		throw new ServiceException(errorMessage);  
			
			
		// --- <<IS-END>> ---

                
	}



	public static final void writeToFile_noValidate (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(writeToFile_noValidate)>> ---
		// @sigtype java 3.5
		// [i] field:0:required userData
		// [i] field:0:required filename
		// [i] field:0:required appendOverwriteFlag
		// {"append","overwrite","failIfFileExists"}
		// Based on Ryan's writeFile service
		
		IDataCursor idcPipeline = pipeline.getCursor();
		String strUserData = null;
		String strFullFilename = null;
		if (idcPipeline.first("userData"))
		{
		  strUserData = (String) idcPipeline.getValue();
		} 
		if (idcPipeline.first("filename"))
		{
		  strFullFilename = (String) idcPipeline.getValue();
		}
		else
		{
		  throw new ServiceException("filename is null!");
		}
		idcPipeline.first("appendOverwriteFlag");
		String appendOverwriteFlag = (String) idcPipeline.getValue();
		
		// *** Check if path is on the allowed list ***
		/*
		 try
		{
		  if (!checkPathValidity(strFullFilename, "write"))
		  {
		    throw new ServiceException("Specified path is not on the write allowed list in the PSUtilities configuration file!");
		  }
		}
		catch (Exception e)
		{
		  throw new ServiceException(e.getMessage());
		}
		*/
		
		// *** End check ***
		
		// Separate filename into path and filename
		// This is done so that the directory can be written (if necessary)
		String separator = System.getProperty("file.separator");
		int indexSeparator = strFullFilename.lastIndexOf(separator);
		if (indexSeparator == -1)
		{
		  // Account for fact that you can use either '\' or '/' in Windows
		  indexSeparator = strFullFilename.lastIndexOf('/');
		}
		String strPathName = strFullFilename.substring(0, indexSeparator + 1);
		String strFileName = strFullFilename.substring(indexSeparator + 1);
		
		FileWriter fw = null;
		try
		{
		  File pathToBeWritten = new File(strPathName);
		  // System.out.println("canonical path = " +
		  // pathToBeWritten.getCanonicalPath());
		
		  // Write the directory...
		  if (pathToBeWritten.exists() == false)
		  {
		    throw new ServiceException("Path does not exist!");
		  }
		
		  // Check if file exists
		  File fileToBeWritten = new File(strFullFilename);
		  if (fileToBeWritten.exists() == true && appendOverwriteFlag != null && appendOverwriteFlag.equals("failIfFileExists"))
		  {
		    throw new ServiceException("File " + strFullFilename + " already exists!");
		  }
		
		  // Write the file...
		  if (appendOverwriteFlag != null && appendOverwriteFlag.equals("overwrite"))
		  {
		    // overwrite
		    fw = new FileWriter(strFullFilename, false);
		  }
		  else
		  {
		    // append
		    fw = new FileWriter(strFullFilename, true);
		  }
		  fw.write(strUserData);
		}
		catch (Exception e)
		{
		  throw new ServiceException(e.getMessage());
		}
		finally
		{
		  // Close the output stream....
		  try
		  {
		    fw.close();
		  }
		  catch (Exception e)
		  {
		  }
		
		  idcPipeline.destroy();
		}
			
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	public static void removePasswordFromDocument(IData document, String list)
	{
		IDataMap idm = new IDataMap(document);
		for(String t : idm.keySet())
		{
			Object obj = idm.get(t);
			if (list.contains(t))
			{
				idm.put(t, "**********");
			}
			else
			{
				removePasswordFromDocument(idm.getAsIData(t),list);
			}
		}
	}
	
	public static void removeNullFromDocument (IData document, String arrayList)
	{
		
		IDataMap idm = new IDataMap(document);
		
		for(String t : idm.keySet()){
			
			Object obj = idm.get(t);
			
			if (arrayList.contains(t)) // The current t is document list
			{
				
				IData[] documentList = idm.getAsIDataArray(t);
				
				if (documentList == null)
					idm.remove(t);
				else
					for (int i = 0; i < documentList.length; i++)
					{
						removeNullFromDocument(documentList[i],arrayList);
						
					}
			}
			else
			{
				
				if (obj == null)
				{
						idm.remove(t);
				}
				else{
						removeNullFromDocument(idm.getAsIData(t), arrayList);
				}
			}
		}
	}
	
	public static void logData(String message)
	{		
		IData logIData = IDataFactory.create();
		IDataCursor pCursor = logIData.getCursor();
	
		IDataUtil.put(pCursor, "message", message);
		try {
			Service.doInvoke("pub.flow", "debugLog", logIData);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		pCursor.destroy();
		
	}
	
	public static void removeNull (IData arrayDocumentItem)
	{
		IDataMap idm = new IDataMap(arrayDocumentItem);
		for(String t : idm.keySet()){
			
			Object obj = idm.get(t);
			if (obj == null)
			{
				idm.remove(t);
			}
			else{
				removeNull(idm.getAsIData(t));
			}
		}
	}
	
	public static IData getQueryIData(String s, IData data){
		IData out = null;
			IDataMap idm = new IDataMap(data);
			
			for(String t : idm.keySet())
			{
				Object obj = idm.get(t); 
				if(obj instanceof IData)
				{
					if (t.equals(s))
					{
						out = (IData)obj;
						break;
					}
				}
				if(obj instanceof IData)
				{
					out = getQueryIData(s, (IData) obj);
					if(out != null)
					{
						break;
					}
				}
			}
		
		return out;
	}
	private static String checkNull(String inputString)
	{
	  if (inputString == null)
	    return "";
	  else
	    return inputString;
	}
	// --- <<IS-END-SHARED>> ---
}

