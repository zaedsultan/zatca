package YXL_Configuration_Properties;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.Properties;
import java.util.StringTokenizer;
// --- <<IS-END-IMPORTS>> ---

public final class java

{
	// ---( internal utility methods )---

	final static java _instance = new java();

	static java _newInstance() { return new java(); }

	static java _cast(Object o) { return (java)o; }

	// ---( server methods )---




	public static final void deleteProperty (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(deleteProperty)>> ---
		// @sigtype java 3.5
		// [i] field:0:required key
		// [i] field:0:required configFileName
		// [o] field:0:required status
		IDataCursor cursor = pipeline.getCursor();
		String inputKey = IDataUtil.getString(cursor, "key");
		String inputConfigFileName = IDataUtil.getString(cursor, "configFileName");
		
		String status = null;
		
		try {
			String currDir = System.getProperty("user.dir");
			InputStream propFile = new FileInputStream(currDir + "/packages/YXL_Configuration_Properties/config/" + inputConfigFileName + ".properties");
			Properties prop = new Properties();
			prop.load(new InputStreamReader(propFile,Charset.forName("UTF-8")));
			
			String ifKeyExist = prop.getProperty(inputKey);
			if(ifKeyExist == null) {
				status = "Failed"; 
				
			}else{
				prop.remove(inputKey);
				status = "success";
				OutputStream output = new FileOutputStream(currDir + "/packages/YXL_Configuration_Properties/config/" + inputConfigFileName + ".properties");
				prop.store(new OutputStreamWriter(output, "UTF-8"), null);
				
			}
			
			
			IDataCursor pipelineCursor_1 = pipeline.getCursor();
			IDataUtil.put( pipelineCursor_1, "status", status );
			
			pipelineCursor_1.destroy();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			IDataCursor pipelineCursor_1 = pipeline.getCursor();
			IDataUtil.put( pipelineCursor_1, "status", "Failed");
			pipelineCursor_1.destroy();
		}
		// --- <<IS-END>> ---

                
	}



	public static final void getAllProperties (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getAllProperties)>> ---
		// @sigtype java 3.5
		// [i] field:0:required configFileName
		// [o] field:0:required value
		IDataCursor cursor = pipeline.getCursor();
		String inputConfigFileName = IDataUtil.getString(cursor, "configFileName");
		
		String outputValue = ",";
		
		try {
			String currDir = System.getProperty("user.dir");
			InputStream propFile = new FileInputStream(currDir + "/packages/YXL_Configuration_Properties/config/" + inputConfigFileName + ".properties");
			Properties prop = new Properties();
			prop.load(new InputStreamReader(propFile,Charset.forName("UTF-8")));
			
			 Enumeration em = prop.keys();
			 
			 while(em.hasMoreElements()){
				 
				 String strKey = (String)em.nextElement();
				 String strValue = (String) prop.get(strKey);
				 String item = strKey + "+" + strValue;
				 outputValue += item + ",";  
				  
				  }
				  
		
			IDataCursor pipelineCursor_1 = pipeline.getCursor();
			IDataUtil.put( pipelineCursor_1, "value", outputValue );
			
			pipelineCursor_1.destroy();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			IDataCursor pipelineCursor_1 = pipeline.getCursor();
			IDataUtil.put( pipelineCursor_1, "value", null);
			pipelineCursor_1.destroy();
		}
		
			
		// --- <<IS-END>> ---

                
	}



	public static final void getFilesList (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getFilesList)>> ---
		// @sigtype java 3.5
		// [o] field:1:required filesList
		String currDir = System.getProperty("user.dir");
		currDir += "/packages/YXL_Configuration_Properties/config/";
		File listOfFiles = new File(currDir);
		String[] filesList = listOfFiles.list();
		
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "filesList", filesList);
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void getProperty (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getProperty)>> ---
		// @sigtype java 3.5
		// [i] field:0:required key
		// [i] field:0:required configFileName
		// [o] field:0:required value
		IDataCursor cursor = pipeline.getCursor();
		String inputKey = IDataUtil.getString(cursor, "key");
		String inputConfigFileName = IDataUtil.getString(cursor, "configFileName");
		
		try {
			String currDir = System.getProperty("user.dir");
			InputStream propFile = new FileInputStream(currDir + "/packages/YXL_Configuration_Properties/config/" + inputConfigFileName + ".properties");
			Properties prop = new Properties();
			prop.load(new InputStreamReader(propFile,Charset.forName("UTF-8")));
			String outputValue = prop.getProperty(inputKey);
			IDataCursor pipelineCursor_1 = pipeline.getCursor();
			IDataUtil.put( pipelineCursor_1, "value", outputValue );
			
			pipelineCursor_1.destroy();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			IDataCursor pipelineCursor_1 = pipeline.getCursor();
			IDataUtil.put( pipelineCursor_1, "value", null);
			pipelineCursor_1.destroy();
		}
		// --- <<IS-END>> ---

                
	}



	public static final void storeProperty (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(storeProperty)>> ---
		// @sigtype java 3.5
		// [i] field:0:required key
		// [i] field:0:required value
		// [i] field:0:required configFileName
		// [o] field:0:required status
		IDataCursor cursor = pipeline.getCursor();
		String inputKey = IDataUtil.getString(cursor, "key");
		String inputValue = IDataUtil.getString(cursor, "value");
		String inputConfigFileName = IDataUtil.getString(cursor, "configFileName");
		
		try {
			String currDir = System.getProperty("user.dir");
			InputStream propFile = new FileInputStream(currDir + "/packages/YXL_Configuration_Properties/config/" + inputConfigFileName + ".properties");
			Properties prop = new Properties();
			prop.load(new InputStreamReader(propFile,Charset.forName("UTF-8")));
			prop.setProperty(inputKey,inputValue);
			OutputStream output = new FileOutputStream(currDir + "/packages/YXL_Configuration_Properties/config/" + inputConfigFileName + ".properties");
			prop.store(new OutputStreamWriter(output, "UTF-8"), null);
			String status = "success";
			
			IDataCursor pipelineCursor_1 = pipeline.getCursor();
			IDataUtil.put( pipelineCursor_1, "status", status );
			pipelineCursor_1.destroy();
			
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			String status = "failed";
			IDataCursor pipelineCursor_1 = pipeline.getCursor();
			IDataUtil.put( pipelineCursor_1, "status", status );
			pipelineCursor_1.destroy();
		}
		// --- <<IS-END>> ---

                
	}
}

