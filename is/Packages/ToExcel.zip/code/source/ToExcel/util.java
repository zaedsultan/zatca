package ToExcel;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.io.*;
import java.util.*;
import org.apache.poi.hssf.usermodel.*;
import java.text.SimpleDateFormat;
import java.util.GregorianCalendar;
import com.wm.app.b2b.server.*;
// --- <<IS-END-IMPORTS>> ---

public final class util

{
	// ---( internal utility methods )---

	final static util _instance = new util();

	static util _newInstance() { return new util(); }

	static util _cast(Object o) { return (util)o; }

	// ---( server methods )---




	public static final void docListToMSExcel (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(docListToMSExcel)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] record:1:required inDocList
		// [i] field:0:optional file_name
		// [i] field:0:optional option {"file","bytes","stream"}
		// [o] object:0:optional bytes
		// [o] object:0:optional stream
		// [o] field:0:optional file_name
		// [o] field:0:required status
		/* Mahesh K Sreenivasulu
		 * Java service class to convert DocList to XLS
		 */
		
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		String file_name = IDataUtil.getString(pipelineCursor, "file_name");
		String option = IDataUtil.getString(pipelineCursor, "option");
		
		String status = "false";
		HSSFWorkbook wb = new HSSFWorkbook();
		HSSFSheet sheet = wb.createSheet("Sheet1");
		HSSFRow row = null;
		HSSFCell cell = null;
		
		if (option == null)
			option = "bytes";
		if (file_name != null)
			option = "file";
		
		try {
		
			String val = "";
		
			// inDocList
			IData[] inDocList = IDataUtil.getIDataArray(pipelineCursor, "inDocList");
		
			if (inDocList != null) {
				// Handle all records - rows
				for (int i = 0; i < inDocList.length; i++) {
					// Create a row and put some cells in it. Rows are 0 based.
					row = sheet.createRow((short) i);
		
					int count = 0;
					IDataCursor idc = inDocList[i].getCursor();
					idc.first();
					boolean more_data = true;
					while (more_data) {
		
						val = (String) idc.getValue();
		
						// Create a cell.
						cell = row.createCell((short) count);
						cell.setCellValue(val);
						count++;
		
						// set status
						status = "true";
		
						more_data = idc.next();
					}
					idc.destroy();
				}
			}
			pipelineCursor.destroy();
		
			if (option.equals("file")) {
				// Write the output to a file
				FileOutputStream fileOut = new FileOutputStream(file_name);
				wb.write(fileOut);
				fileOut.close();
				IDataCursor pipelineCursor2 = pipeline.getCursor();
				IDataUtil.put(pipelineCursor2, "bytes", null);
				IDataUtil.put(pipelineCursor2, "stream", null);
				pipelineCursor2.destroy();
		
			}
			else if (option.equals("bytes")) {
				ByteArrayOutputStream stream = new ByteArrayOutputStream();
				wb.write(stream);
				IDataCursor pipelineCursor2 = pipeline.getCursor();
				IDataUtil.put(pipelineCursor2, "bytes", stream.toByteArray());
				pipelineCursor2.destroy();
				stream.close();
			}
			else if (option.equals("stream")) {
				ByteArrayOutputStream stream = new ByteArrayOutputStream();
				wb.write(stream);
				IDataCursor pipelineCursor2 = pipeline.getCursor();
				IDataUtil.put(pipelineCursor2, "stream", stream);
				pipelineCursor2.destroy();
				stream.close();
			}
		
		} catch(Exception e) {
			pipelineCursor.destroy();
			throw new ServiceException(e.getMessage());
		}
		
		// pipeline
		IDataCursor pipelineCursor1 = pipeline.getCursor();
		IDataUtil.put(pipelineCursor1, "file_name", file_name);
		IDataUtil.put(pipelineCursor1, "status", status);
		pipelineCursor1.destroy();
			
		// --- <<IS-END>> ---

                
	}



	public static final void stringListToMSExcel (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(stringListToMSExcel)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:1:required inStringList
		// [i] field:0:optional file_name
		// [i] field:0:optional option {"file","bytes","stream"}
		// [o] field:0:optional file_name
		// [o] field:0:required status
		/* Mahesh K Sreenivasulu
		 * Java service class to convert stringList to XLS
		 */
		
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		String file_name = IDataUtil.getString(pipelineCursor, "file_name");
		String option = IDataUtil.getString(pipelineCursor, "option");
		
		if (option == null)
			option = "bytes";
		if (file_name != null)
			option = "file";
		
		String status = "false";
		HSSFWorkbook wb = new HSSFWorkbook();
		HSSFSheet sheet = wb.createSheet("Sheet1");
		HSSFRow row = null;
		HSSFCell cell = null;
		
		
		try {
		
		
		 String val = "";
		
		 // inStringList
		 String[] inStringList = IDataUtil.getStringArray(pipelineCursor, "inStringList");
		
		 if (inStringList != null) {
		  // Handle all records - rows
		  for (int i = 0; i < inStringList.length; i++) {
		   // Create a row and put some cells in it. Rows are 0 based.
		   row = sheet.createRow((short) i);
		
		   int count = 0;
		
		   IDataCursor idc = pipeline.getCursor();
		   // idc.first();
		   boolean more_data = true;
		   while (more_data) {
		
		    val = inStringList[i];
		
		    // Create a cell.
		    cell = row.createCell((short) count);
		    cell.setCellValue(val);
		
		    // set status
		    status = "true";
		
		    more_data = idc.next();
		   }
		   idc.destroy();
		  }
		 }
		 pipelineCursor.destroy();
		
		
		 if (option.equals("file")) {
				// Write the output to a file
				FileOutputStream fileOut = new FileOutputStream(file_name);
				wb.write(fileOut);
				fileOut.close();
				IDataCursor pipelineCursor2 = pipeline.getCursor();
				IDataUtil.put(pipelineCursor2, "bytes", null);
				IDataUtil.put(pipelineCursor2, "stream", null);
				pipelineCursor2.destroy();
		
			}
			else if (option.equals("bytes")) {
				ByteArrayOutputStream stream = new ByteArrayOutputStream();
				wb.write(stream);
				IDataCursor pipelineCursor2 = pipeline.getCursor();
				IDataUtil.put(pipelineCursor2, "bytes", stream.toByteArray());
				pipelineCursor2.destroy();
				stream.close();
			}
			else if (option.equals("stream")) {
				ByteArrayOutputStream stream = new ByteArrayOutputStream();
				wb.write(stream);
				IDataCursor pipelineCursor2 = pipeline.getCursor();
				IDataUtil.put(pipelineCursor2, "stream", stream);
				pipelineCursor2.destroy();
				stream.close();
			}
		
		} catch (Exception e) {
		 //e.printStackTrace();
		 pipelineCursor.destroy();
		 throw new ServiceException(e.getMessage());
		}
		
		// pipeline
		IDataCursor pipelineCursor1 = pipeline.getCursor();
		IDataUtil.put(pipelineCursor1, "file_name", file_name);
		IDataUtil.put(pipelineCursor1, "status", status);
		pipelineCursor1.destroy();
			
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---

	
	// --- <<IS-END-SHARED>> ---
}

