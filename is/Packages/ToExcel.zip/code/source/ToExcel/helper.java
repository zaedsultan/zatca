package ToExcel;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import com.wm.util.pluggable.WmIndexException;
import com.wm.util.Table;
// --- <<IS-END-IMPORTS>> ---

public final class helper

{
	// ---( internal utility methods )---

	final static helper _instance = new helper();

	static helper _newInstance() { return new helper(); }

	static helper _cast(Object o) { return (helper)o; }

	// ---( server methods )---




	public static final void stringTableToDocList (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(stringTableToDocList)>> ---
		// @sigtype java 3.5
		// [i] field:2:required stringTable
		// [i] field:1:required columnNames
		// [o] record:1:required docList
		// pipeline
		
		    IDataCursor id = pipeline.getCursor();
		    Object o = null;
		    if (id.first("stringTable")) {
		      o = id.getValue();
		    }
		    String[][] data = (o instanceof String[][]) ? (String[][])o : (String[][])null;
		    
		    if (id.first("columnNames")) {
		      o = id.getValue();
		    }
		    String[] colNames = (o instanceof String[]) ? (String[])o : null;
		    String tableName = null;
		    
		    if (id.first("tableName")) {
		      tableName = IDataUtil.getString(id);
		    }
		   
		
		    
		    Table t = new Table(tableName, colNames);
		    for (int row = 0; row < data.length; row++) {
		      
		      IData r = IDataFactory.create();
		      IDataCursor idc = r.getCursor();
		      for (int col = 0; col < colNames.length; col++)
		      {
		        idc.insertAfter(colNames[col], data[row][col]);
		      }
		      idc.destroy();
		   
		        try {
					t.putItemAt(r, row);
				} catch (WmIndexException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		      
		     
		    } 
		 		    
		    IDataUtil.put(id, "docList", t);
		    
		    id.destroy();
		  
		
			
		// --- <<IS-END>> ---

                
	}
}

