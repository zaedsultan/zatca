mv temp.process $1/$2.process
