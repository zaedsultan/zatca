mkdir $1
